#!/usr/bin/env python3
import argparse
import json
import os
import sys


MODEL_ID = "pyannote/speaker-diarization-community-1"


def configure_environment(cache_dir: str) -> None:
    extra_paths = [
        "/opt/homebrew/bin",
        "/usr/local/bin",
        "/opt/local/bin",
        "/usr/bin",
        "/bin",
    ]
    current_path = os.environ.get("PATH", "")
    os.environ["PATH"] = ":".join([current_path, *extra_paths]) if current_path else ":".join(extra_paths)
    os.environ.setdefault("HF_HOME", cache_dir)
    os.environ.setdefault("HF_HUB_CACHE", os.path.join(cache_dir, "hub"))
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    os.environ.setdefault("MPLCONFIGDIR", os.path.join(cache_dir, "matplotlib"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", required=True)
    parser.add_argument("--cache-dir", required=True)
    args = parser.parse_args()

    configure_environment(args.cache_dir)

    try:
        from pyannote.audio import Pipeline

        token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN")
        pipeline = Pipeline.from_pretrained(MODEL_ID, token=token)
        if pipeline is None:
            raise RuntimeError(
                "pyannote diarization model could not be loaded. "
                "Accept the model terms on Hugging Face and set HF_TOKEN if required."
            )

        output = pipeline(args.audio)
        diarization = getattr(output, "exclusive_speaker_diarization", None)
        if diarization is None:
            diarization = getattr(output, "speaker_diarization", output)

        segments = []
        for turn, _, speaker in diarization.itertracks(yield_label=True):
            segments.append(
                {
                    "start": round(float(turn.start), 3),
                    "end": round(float(turn.end), 3),
                    "speaker": str(speaker),
                }
            )

        print(json.dumps({"segments": segments}, ensure_ascii=False))
    except Exception as error:
        print(f"Speaker diarization failed: {error}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
