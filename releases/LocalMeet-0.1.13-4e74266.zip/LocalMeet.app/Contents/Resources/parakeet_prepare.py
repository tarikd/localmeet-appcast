#!/usr/bin/env python3
import argparse
import os


def configure_process_environment() -> None:
    extra_paths = [
        "/opt/homebrew/bin",
        "/usr/local/bin",
        "/opt/local/bin",
        "/usr/bin",
        "/bin",
    ]
    current_path = os.environ.get("PATH", "")
    os.environ["PATH"] = ":".join([current_path, *extra_paths]) if current_path else ":".join(extra_paths)
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--cache-dir", required=True)
    args = parser.parse_args()

    configure_process_environment()
    from parakeet_mlx import from_pretrained

    from_pretrained(args.model, cache_dir=args.cache_dir)
    print(f"ready: {args.model}")


if __name__ == "__main__":
    main()
