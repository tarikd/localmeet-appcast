#!/usr/bin/env python3
import argparse
import json
import os
import shutil
import sys


def configure_process_environment() -> None:
    extra_paths = [
        "/opt/homebrew/bin",
        "/usr/local/bin",
        "/opt/local/bin",
        "/usr/bin",
        "/bin",
    ]
    current_path = os.environ.get("PATH", "")
    os.environ["PATH"] = ":".join([current_path, *extra_paths]) if current_path else ":".join(extra_paths)
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--cache-dir", required=True)
    parser.add_argument("--chunk-duration", type=float, default=120.0)
    parser.add_argument("--overlap-duration", type=float, default=15.0)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    configure_process_environment()
    if shutil.which("ffmpeg") is None:
        print(
            "Parakeet could not find ffmpeg. Install it with `brew install ffmpeg`, "
            "or make sure /opt/homebrew/bin/ffmpeg exists.",
            file=sys.stderr,
        )
        raise SystemExit(1)

    try:
        from parakeet_mlx import from_pretrained

        model = from_pretrained(args.model, cache_dir=args.cache_dir)
        result = model.transcribe(
            args.audio,
            chunk_duration=args.chunk_duration if args.chunk_duration > 0 else None,
            overlap_duration=args.overlap_duration,
        )
        if args.json:
            print(
                json.dumps(
                    {
                        "text": result.text.strip(),
                        "segments": [
                            {
                                "start": round(float(sentence.start), 3),
                                "end": round(float(sentence.end), 3),
                                "text": sentence.text.strip(),
                            }
                            for sentence in result.sentences
                        ],
                    },
                    ensure_ascii=False,
                )
            )
        else:
            print(result.text.strip())
    except Exception as error:
        print(f"Parakeet transcription failed: {error}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
